from extentions import db
from datetime import datetime, timezone
from flask_security.core import UserMixin, RoleMixin

class BaseModel(db.Model):
    __abstract__ = True
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))


class User(BaseModel, UserMixin):
    __tablename__ = 'users'

    name = db.Column(db.String, nullable=True)
    email = db.Column(db.String, nullable=False, unique=True)
    password = db.Column(db.String, nullable=False)
    #for flask security
    fs_uniquifier = db.Column(db.String, unique=True, nullable=False)
    active = db.Column(db.Boolean(), default=True)
    #If active=false, user cannot login

    # Relationships
    roles=db.relationship('Role', secondary='user_roles', backref='users')
    #role can be "admin", "doctor", "patient"
    doctor_profile = db.relationship("Doctor", backref="user", uselist=False)
    patient_profile = db.relationship("Patient", backref="user", uselist=False)

class Role(BaseModel, RoleMixin):
    __tablename__ = 'roles'
    name = db.Column(db.String(80), unique=True)
    description = db.Column(db.String(255))

class UserRoles(BaseModel):
    __tablename__ = 'user_roles'
    user_id = db.Column(db.Integer(), db.ForeignKey('users.id'))
    role_id = db.Column(db.Integer(), db.ForeignKey('roles.id'))

class Specialization(db.Model):
    __tablename__ = 'specializations'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String, nullable=False, unique=True)
    description = db.Column(db.Text)

    # Relationships
    doctors = db.relationship("Doctor", backref="specialization_ref", lazy=True)


class Doctor(BaseModel):
    __tablename__ = 'doctors'

    u_id = db.Column(db.Integer, db.ForeignKey('users.id'))  # FK to User
    specialization_id = db.Column(db.Integer, db.ForeignKey('specializations.id'), nullable=False)
    availability = db.Column(db.JSON, nullable=True)  # Store availability as JSON (e.g., {"Monday": ["10:00", "14:00"]})
    contact_number = db.Column(db.String, nullable=True)

    # Relationships
    appointments = db.relationship("Appointment", backref="doctor", lazy=True)


class Patient(BaseModel):
    __tablename__ = 'patients'

    u_id = db.Column(db.Integer, db.ForeignKey('users.id'))  # FK to User
    age = db.Column(db.Integer, nullable=True)
    gender = db.Column(db.String, nullable=True)
    contact_number = db.Column(db.String, nullable=True)
    address = db.Column(db.String, nullable=True)
    emergency_contact = db.Column(db.String, nullable=True)

    # Relationships
    appointments = db.relationship("Appointment", backref="patient", lazy=True)



class Appointment(BaseModel):
    __tablename__ = 'appointments'

    doctor_id = db.Column(db.Integer, db.ForeignKey('doctors.id'), nullable=False)
    patient_id = db.Column(db.Integer, db.ForeignKey('patients.id'), nullable=False)
    appointment_date = db.Column(db.Date, nullable=False)
    appointment_time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String, default='scheduled')  # scheduled, completed, cancelled

    # Relationships
    treatment = db.relationship("Treatment", backref="appointment", uselist=False)



class Treatment(db.Model):
    __tablename__ = 'treatments'

    appointment_id = db.Column(db.Integer, db.ForeignKey('appointments.id'), primary_key=True)
    diagnosis = db.Column(db.Text, nullable=True)
    prescription = db.Column(db.JSON, nullable=True)  # Store as JSON: [{"med": "Paracetamol", "dose": "500mg", "duration": "5 days"}]
    notes = db.Column(db.Text, nullable=True)

    created_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    updated_at = db.Column(db.DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))