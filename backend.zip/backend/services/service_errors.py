class ServiceError(Exception):
    """Base class for service-related errors."""
    pass