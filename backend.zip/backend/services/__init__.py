from services.user_service import UserService
from services.doctor_service import DocService
from services.patient_service import PatientService
from services.appointment_service import AppointmentService
from services.treatment_service import TreatmentService
from services.specialization_service import SpecializationService

from services.service_errors import ServiceError