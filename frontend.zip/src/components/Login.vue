<script setup></script>
<template>
    <div class="body">
        <div style="width: 51vw;" class="d-flex flex-column justify-content-center align-items-center gap-5">
            <div class="log">
                <div class="inps">
                    <h3 class="text-success fw-bold text-center">Your Reliable Hospital Management Platform</h3>

                    <!-- Login Form -->
                    <form class="d-flex flex-column align-items-center" @submit.prevent="login">
                        <div class="mb-3">
                            <label for="email" class="form-label">Registered Email-Id: </label>
                            <input v-model="email" type="email" class="form-control" id="email" placeholder="Email-ID" required>
                        </div>

                        <div class="mb-3">
                            <label for="pass" class="form-label">Password: </label>
                            <input v-model="password" type="password" class="form-control" id="pass" placeholder="Password" required>
                        </div>

                        <input type="submit" value="Login" class="btn btn-success">
                    </form>

                    <!-- Error message -->
                    <!-- <div v-if="errorMessage" class="alert alert-danger mt-2 w-100 text-center">
                        {{ errorMessage }}
                    </div> -->
                </div>

                <a href="/register">Don't have an account? Create One!</a>
            </div>
        </div>
    </div>
</template>

<style scoped>
.body{
    display: flex;
    height: 72.7vh;
    background-color: #d8f1ed;
    justify-content: center;
    align-items: center;
}
.inps{
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 20px;
}
/* .img{
    height:97vh;
    left: 10px;
    width: 49vw;
} */
.inps div{
    display: grid;
    grid-template-columns: 2fr 3fr;
    gap: 10px;
}
.log{
    max-height: 460px;
    background-color: #f5e5e5;
    display: flex;
    flex-direction: column;
    overflow-y: auto;
    box-shadow: 11px 9px 20px 6px #5a5a5a;
    border-radius: 15px;
    padding: 5px;
    gap: 10px;
    align-items: center;
}
</style>
