
<template>
        <h1>Welcome to the Signup Page</h1>
</template>